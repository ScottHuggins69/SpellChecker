﻿using System;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using SpellChecker.Contracts;
using SpellChecker.Core;

namespace SpellChecker.Tests
{

    [TestClass]
    public class DictionaryDotComSpellCheckerTests
    {

        ISpellChecker spellChecker;

        [TestInitialize]
        public void TestFixureSetUp()
        {
            spellChecker = new DictionaryDotComSpellChecker();
        }

        [TestMethod]
        public void Check_That_FileAndServe_Is_Misspelled()
        {
            // act
            bool result = spellChecker.Check("FileAndServe");

            // assert
            Assert.AreEqual(result, false);
        }

        [TestMethod]
        public void Check_That_South_Is_Not_Misspelled()
        {
            // act
            bool result = spellChecker.Check("South");

            // assert
            Assert.AreEqual(result, true);
        }

        [TestCleanup]
        public void CleanUp()
        {
            spellChecker = null;
        }

    }

}
