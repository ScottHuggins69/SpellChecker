﻿using System;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using SpellChecker.Contracts;
using SpellChecker.Core;

namespace SpellChecker.Tests
{

    [TestClass]
    public class MnemonicSpellCheckerIBeforeETests
    {

        ISpellChecker spellChecker;

        [TestInitialize]
        public void TestFixtureSetUp()
        {
            spellChecker = new MnemonicSpellCheckerIBeforeE();
        }

        [TestMethod]
        public void Check_Word_That_Contains_I_Before_E_Is_Spelled_Correctly()
        {
            // act
            bool result = spellChecker.Check("friend");

            // assert
            Assert.AreEqual(result, true);
        }

        [TestMethod]
        public void Check_Word_That_Contains_I_Before_E_Is_Spelled_Incorrectly()
        {
            // act
            bool result = spellChecker.Check("seeing");

            // assert
            Assert.AreEqual(result, false);
        }

        [TestCleanup]
        public void CleanUp()
        {
            spellChecker = null;
        }

    }

}
