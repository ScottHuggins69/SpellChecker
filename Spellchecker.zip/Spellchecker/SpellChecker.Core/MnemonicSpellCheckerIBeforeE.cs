﻿using System;

using SpellChecker.Contracts;

namespace SpellChecker.Core
{

    /// <summary>
    /// This spell checker implements the following rule:
    /// "I before E, except after C" is a mnemonic rule of thumb for English spelling.
    /// If one is unsure whether a word is spelled with the sequence ei or ie, the rhyme
    /// suggests that the correct order is ie unless the preceding letter is c, in which case it is ei.
    /// 
    /// Examples: believe, fierce, collie, die, friend,receive, deceive, ceiling, receipt would be evaulated as spelled correctly
    /// heir, protein, science, seeing, their, and veil would be evaluated as spelled incorrectly.
    /// </summary>
    public class MnemonicSpellCheckerIBeforeE :
        ISpellChecker
    {

        /// <summary>
        /// Returns false if the word contains a letter sequence of "ie" when it is immediately preceded by c.
        /// Returns false if the word contains "ei" when not preceded by c
        /// </summary>
        /// <param name="word">The word to be checked</param>
        /// <returns>true when the word is spelled correctly, false otherwise</returns>
        public bool Check(string word)
        {
            bool bRetVal = true;
            try
            {
                // check if we have IE in word
                int pos = word.ToUpper().IndexOf("IE");
                if (pos != -1 && pos != 0) // if = 0, then it's at beginning of word
                {
                    if (word.Substring(pos - 1, 1).ToUpper().IndexOf("C") != -1)
                        bRetVal = false;
                }

                if (pos == -1) // if we didn't find IE, check for EI in word
                {
                    pos = word.ToUpper().IndexOf("EI");
                    if ((pos != -1 && pos != 0) && word.Substring(pos - 1, 1).ToUpper().IndexOf("C") == -1) // if we don't have C before it, then assume bad spelling
                        bRetVal = false;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return bRetVal;
        }

    }

}
