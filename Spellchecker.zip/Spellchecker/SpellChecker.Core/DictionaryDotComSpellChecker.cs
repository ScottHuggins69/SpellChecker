﻿using System;
using System.Net;
using SpellChecker.Contracts;

namespace SpellChecker.Core
{

    /// <summary>
    /// This is a dictionary based spell checker that uses dictionary.com to determine if
    /// a word is spelled correctly.
    /// 
    /// The URL to do this looks like this: http://dictionary.reference.com/browse/<word>
    /// where <word> is the word to be checked.
    /// 
    /// We look for something in the response that gives us a clear indication whether the
    /// word is spelled correctly or not.
    /// </summary>
    public class DictionaryDotComSpellChecker :
        ISpellChecker
    {
        private readonly string _url = "http://dictionary.reference.com/browse/{word}/";

        /// <summary>
        /// This will use dictionary.com to take a word and return true if spelled correctly else false.
        /// </summary>
        /// <param name="word">the word to spell check</param>
        /// <returns>true if word is spelled correctly, false if not spelled correctly.</returns>
        public bool Check(string word)
        {
            bool bRetVal = true;

            try
            {
                string s;
                using (var client = new WebClient())
                {
                    try
                    {
                        // invoke webpage to do the spell check
                        s = client.DownloadString(_url.Replace("{word}", word));
                    }
                    catch (WebException wex)
                    {
                        // dictionary.com will return 404 if spelling error (doesn't recognize word)
                        if (((HttpWebResponse)wex.Response).StatusCode == HttpStatusCode.NotFound)
                        {
                            bRetVal = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return bRetVal;
        }

    }

}
